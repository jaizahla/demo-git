console.log("✅ script.js berhasil dipanggil!");
alert("Anda sedang membuka portofolio Jaizah Lutfiyah Azzahra ");
